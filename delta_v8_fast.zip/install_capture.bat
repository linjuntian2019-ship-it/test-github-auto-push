@echo off
cd /d "%~dp0"
if not exist ".venv-gpu\Scripts\python.exe" (
  echo Copy this update into your existing V6 folder, keeping .venv-gpu.
  pause
  exit /b 1
)
"%USERPROFILE%\.local\bin\uv.exe" pip install --python ".venv-gpu\Scripts\python.exe" dxcam
if errorlevel 1 (
  echo DXCAM install failed. Capture will fall back to MSS.
  pause
  exit /b 1
)
echo Capture dependency installed. Run start_v7.bat.
pause
