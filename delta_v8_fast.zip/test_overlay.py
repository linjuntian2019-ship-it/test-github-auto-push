"""15-second desktop overlay test. Does not load AI or move the mouse."""
import sys
import time
import ctypes


def main():
    if sys.platform != 'win32':
        raise SystemExit('Windows required')
    user32 = ctypes.WinDLL('user32')
    user32.SetProcessDPIAware()
    from overlay import Overlay
    # Disable capture exclusion only for this diagnostic so screenshots can show the circle.
    overlay = Overlay(exclude_from_capture=False)
    width, height = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    print(f'OVERLAY TEST: primary screen {width}x{height}; 15 seconds; End exits.', flush=True)
    print('Does not move mouse. Look for a blue circle on the desktop.', flush=True)
    try:
        deadline = time.perf_counter() + 15
        while time.perf_counter() < deadline:
            if user32.GetAsyncKeyState(0x23) & 0x8000:
                break
            overlay.show(0, 0, width, height, None, 'OVERLAY TEST - DESKTOP - NO MOUSE CONTROL')
            time.sleep(.05)
    finally:
        overlay.close()


if __name__ == '__main__':
    main()
