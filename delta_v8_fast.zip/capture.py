"""Synchronous fresh-frame DXGI capture, with an explicit MSS fallback."""
import re
import ctypes
import numpy as np


class Capture:
    def __init__(self, screen, mode='auto'):
        self.screen, self.camera = screen, None
        self.backend = 'mss'
        user32 = ctypes.WinDLL('user32')
        self.primary_width = user32.GetSystemMetrics(0)
        self.primary_height = user32.GetSystemMetrics(1)
        if mode != 'mss':
            try:
                import dxcam
                outputs = dxcam.output_info()
                matches = re.findall(r'Device\[(\d+)\]\s+Output\[(\d+)\]:[^\n]*Primary:True', outputs)
                if len(matches) != 1:
                    raise RuntimeError('Cannot identify one primary DXGI output: ' + outputs)
                device, output = map(int, matches[0])
                self.camera = dxcam.create(device_idx=device, output_idx=output, output_color='BGR')
                self.backend = 'dxcam'
                print(f'CAPTURE: DXCAM primary Device[{device}] Output[{output}]', flush=True)
            except Exception as exc:
                if mode == 'dxcam':
                    raise RuntimeError('DXCAM unavailable: ' + str(exc)) from exc
                print('CAPTURE: MSS fallback:', str(exc), flush=True)
        else:
            print('CAPTURE: MSS requested', flush=True)

    def grab(self, left, top, width, height):
        on_primary = (0 <= left and 0 <= top and left+width <= self.primary_width
                      and top+height <= self.primary_height)
        if self.camera is not None and on_primary:
            try:
                self.backend = 'dxcam'
                # None means no new desktop frame: caller skips inference and movement.
                return self.camera.grab(region=(left, top, left+width, top+height))
            except Exception as exc:
                print('CAPTURE: DXCAM failed; switching to MSS:', str(exc), flush=True)
                try:
                    self.camera.release()
                except Exception:
                    pass
                self.camera = None
        self.backend = 'mss'
        return np.array(self.screen.grab(dict(left=left, top=top, width=width, height=height)))[:, :, :3].copy()

    def close(self):
        if self.camera is not None:
            self.camera.release()
            self.camera = None
