"""Fresh-image LK continuation and time-based fractional mouse controller."""
import math
import cv2
import numpy as np
from targeting import TargetTracker, Selection


class VisualTracker(TargetTracker):
    def reset(self):
        super().reset()
        self.gray = None
        self.points = None
        self.measured_at = None
        self.frame_at = None

    def update_frame(self, boxes, frame, radius, now):
        h, w = frame.shape[:2]
        if self.shape != (w, h):
            self.reset()
            self.shape = (w, h)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        predicted = None
        # Never use a stale position: require current-frame forward/backward agreement.
        if (self.box is not None and self.gray is not None and self.points is not None
                and self.frame_at is not None and 0 < now-self.frame_at < .12
                and self.measured_at is not None and now-self.measured_at <= .12):
            p, ok, err = cv2.calcOpticalFlowPyrLK(self.gray, gray, self.points, None,
                                                winSize=(21, 21), maxLevel=3)
            if p is not None:
                back, bok, _ = cv2.calcOpticalFlowPyrLK(gray, self.gray, p, None,
                                                      winSize=(21,21), maxLevel=3)
                if back is not None:
                    good = (ok.ravel() == 1) & (bok.ravel() == 1)
                    good &= np.max(np.abs(back-self.points), axis=(1,2)) < 1.0
                    good &= err.ravel() < 20
                    shifts = (p-self.points).reshape(-1,2)[good]
                    if len(shifts) >= 6:
                        shift = np.median(shifts, axis=0)
                        consistent = np.linalg.norm(shifts-shift, axis=1) < 2.5
                        if consistent.mean() >= .75 and np.linalg.norm(shift) < min(w,h)*.08:
                            b = self.box
                            predicted = tuple(v+float(shift[i%2]) for i,v in enumerate(b))
                            if not (0 <= predicted[4] < w and 0 <= predicted[5] < h):
                                predicted = None
        if predicted is not None:
            self.box = predicted  # association now uses current-image motion
        result = super().update(boxes, w, h, radius, now)
        if result.target is not None:
            # Filter only the detector innovation around the motion-transported head.
            # Do not average absolute screen coordinates (which lags camera movement).
            if predicted is not None and result.status == 'TRACKED':
                target = tuple(predicted[i+4]*.25 + result.target[i]*.75 for i in range(2))
                result.target = target
                result.box = tuple(result.box[:4])+target
                self.box = result.box
            self.measured_at = now
        elif predicted is not None and result.status in ('NO_DETECTION','HEAD_JUMP'):
            result = Selection(predicted[4:6], predicted, result.detected, result.in_range,
                               'FLOW_TRACKED', self.track_id)
        self.gray, self.frame_at = gray, now
        self.points = None
        if result.target is not None:
            # Track texture around head, not the whole person or background.
            x,y = result.target
            bw = result.box[2]-result.box[0]
            bh = result.box[3]-result.box[1]
            rx,ry = max(8,bw*.16),max(8,bh*.075)
            mask = np.zeros_like(gray)
            x1,x2 = max(0,int(x-rx)),min(w,int(x+rx)+1)
            y1,y2 = max(0,int(y-ry)),min(h,int(y+ry)+1)
            mask[y1:y2,x1:x2] = 255
            self.points = cv2.goodFeaturesToTrack(gray, maxCorners=35, qualityLevel=.03,
                                                  minDistance=3, mask=mask, blockSize=3)
        return result


class FractionalController:
    def __init__(self, gain=1.2, pixels_per_count=(1.,1.), max_step=120.):
        self.max_step = max_step
        self.gain = gain
        self.scale = pixels_per_count
        self.reset()

    def reset(self):
        self.residual = [0.,0.]
        self.previous = [0.,0.]
        self.identity = None
        self.in_deadzone = False

    def update(self, target, width, height, dt, identity, cautious=False):
        if target is None or dt <= 0 or dt > .12:
            self.reset()
            return 0,0
        if identity != self.identity:
            self.reset()
            self.identity = identity
        error = (target[0]-width/2, target[1]-height/2)
        distance = math.hypot(*error)
        self.in_deadzone = distance <= 2
        if self.in_deadzone:
            self.residual = [0.,0.]
            return 0,0
        # Exponential approach has the same response across capture frame rates.
        rate = (8 + 16*min(1,distance/160))*self.gain/1.2
        alpha = 1-math.exp(-rate*min(dt,.05))
        if cautious:
            alpha *= .5
        values = [error[i]*alpha/self.scale[i] for i in range(2)]
        length = math.hypot(*values)
        cap = self.max_step*min(dt/.05,1)
        if length > cap:
            values = [v*cap/length for v in values]
        out=[]
        for i,v in enumerate(values):
            if error[i]*self.previous[i] < 0:
                self.residual[i] = 0
            value = v+self.residual[i]
            step = math.trunc(value)
            self.residual[i] = value-step
            self.previous[i] = error[i]
            out.append(step)
        return tuple(out)
