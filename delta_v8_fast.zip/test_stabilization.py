import unittest
import cv2
import numpy as np
from stabilization import VisualTracker, FractionalController

class Checks(unittest.TestCase):
    def test_fractional_accumulation(self):
        c=FractionalController()
        steps=[c.update((103,100),200,200,.008,1)[0] for _ in range(30)]
        self.assertGreater(sum(steps),0)
        self.assertFalse(c.in_deadzone)
        self.assertEqual(c.update(None,200,200,.01,1),(0,0))
        self.assertEqual(c.residual,[0,0])

    def test_closed_loop_and_frame_rates(self):
        final=[]
        for hz in (30,60,120):
            c=FractionalController();x,y=250.,150.
            for _ in range(hz):
                dx,dy=c.update((500+x,500+y),1000,1000,1/hz,1)
                x-=dx;y-=dy
            final.append(np.hypot(x,y))
        self.assertLess(max(final),3)

    def test_current_image_flow_and_expiry(self):
        rng=np.random.default_rng(4)
        frame=np.zeros((240,320,3),np.uint8)
        frame[50:110,110:170]=rng.integers(0,256,(60,60,3),dtype=np.uint8)
        box=[90,40,190,220,140,80]
        t=VisualTracker()
        t.update_frame([box],frame,300,1.)
        moved=cv2.warpAffine(frame,np.float32([[1,0,4],[0,1,2]]),(320,240))
        s=t.update_frame([],moved,300,1.03)
        self.assertEqual(s.status,'FLOW_TRACKED')
        self.assertLess(np.linalg.norm(np.array(s.target)-[144,82]),1.)
        s=t.update_frame([],moved,300,1.2)
        self.assertIsNone(s.target)
        t.reset()
        self.assertIsNone(t.update_frame([],moved,300,1.22).target)

    def test_occlusion_rejected(self):
        rng=np.random.default_rng(5)
        f=rng.integers(0,256,(240,320,3),dtype=np.uint8)
        t=VisualTracker();t.update_frame([[90,40,190,220,140,80]],f,300,1.)
        s=t.update_frame([],np.zeros_like(f),300,1.03)
        self.assertIsNone(s.target)

if __name__=='__main__':unittest.main()
