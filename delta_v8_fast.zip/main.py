"""Windows screen-detection prototype. No game-specific model included."""
import argparse
import csv
import math
import ctypes
import os
from ctypes import wintypes
import sys
import time

from targeting import head_point
from stabilization import VisualTracker, FractionalController


def main():
    if sys.platform != 'win32':
        raise SystemExit('This prototype requires Windows.')
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='yolov8n-pose.pt')
    parser.add_argument('--head-class', type=int, help='Explicit class ID for a head-only detection model')
    parser.add_argument('--device', default='auto')
    parser.add_argument('--video', help='Video file; mouse movement disabled')
    parser.add_argument('--preview', action='store_true', help='Show separate preview; keep outside captured region')
    parser.add_argument('--conf', type=float, default=0.25)
    parser.add_argument('--imgsz', type=int, default=960)
    parser.add_argument('--gain', type=float, default=1.2)
    parser.add_argument('--max-step', type=float, default=120.)
    parser.add_argument('--capture', choices=['auto', 'dxcam', 'mss'], default='auto')
    parser.add_argument('--no-overlay', action='store_true')
    parser.add_argument('--pixels-per-count', type=float, nargs=2, default=None, metavar=('X', 'Y'))
    parser.add_argument('--head-conf', type=float, default=0.5)
    args = parser.parse_args()
    if not 0 < args.conf <= 1 or not 0 < args.gain <= 20 or not math.isfinite(args.gain) or args.imgsz < 32 or args.imgsz % 32:
        parser.error('conf must be in (0,1], gain in (0,20]; imgsz must be a positive multiple of 32')
    if not math.isfinite(args.max_step) or not 0 < args.max_step <= 1200:
        parser.error('max-step must be in (0,1200]')
    if not 0 < args.head_conf <= 1:
        parser.error('head-conf must be in (0,1]')
    if args.pixels_per_count is None:
        import json
        from pathlib import Path
        calibration = Path(__file__).with_name('calibration.json')
        args.pixels_per_count = json.loads(calibration.read_text())['pixels_per_count'] if calibration.exists() else (1.,1.)
        print('Calibration:', 'loaded' if calibration.exists() else 'not measured; using reference scale 1:1', flush=True)
    if len(args.pixels_per_count) != 2:
        parser.error('calibration requires X and Y scales')
    if any(not math.isfinite(v) or v <= 0 for v in args.pixels_per_count):
        parser.error('pixels-per-count must contain two positive finite measurements')
    print('HEAD TRACK V8 FAST | conf=', args.conf, '| preview=', args.preview, flush=True)
    user32 = ctypes.WinDLL('user32', use_last_error=True)
    user32.SetProcessDPIAware()
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.POINT)]
    user32.IsWindow.argtypes = [wintypes.HWND]
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.mouse_event.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                   wintypes.DWORD, ctypes.c_size_t]

    import cv2
    import mss
    import numpy as np
    from ultralytics import YOLO

    import torch
    if args.device == 'auto':
        args.device = '0' if torch.cuda.is_available() else 'cpu'
    print('Inference device:', args.device, flush=True)
    if args.device == 'cpu':
        print('CPU 推理：不保证识别延迟减半。', flush=True)
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    def window_info(handle):
        title_buf = ctypes.create_unicode_buffer(512)
        class_buf = ctypes.create_unicode_buffer(256)
        user32.GetWindowTextW(handle, title_buf, len(title_buf))
        user32.GetClassNameW(handle, class_buf, len(class_buf))
        return title_buf.value, class_buf.value
    model = YOLO(args.model)
    if model.task == 'pose':
        person_ids = [int(k) for k, v in model.names.items() if v == 'person']
    elif model.task == 'detect' and args.head_class is not None:
        if args.head_class not in model.names:
            raise SystemExit('head-class is not in model.names: '+str(model.names))
        person_ids = [args.head_class]
        print('Head-box model: aiming at box center; this is not a forehead landmark.', flush=True)
    else:
        raise SystemExit('Use a COCO pose model, or a verified head detection model with --head-class ID.')
    if not person_ids:
        raise SystemExit('Model must contain a class named person.')
    video = cv2.VideoCapture(args.video) if args.video else None
    if video is not None and not video.isOpened():
        raise SystemExit('Cannot open the video file.')
    def held(key):
        return bool(user32.GetAsyncKeyState(key) & 0x8000)

    print('HEAD TRACK V8: verified short optical flow; fractional time-based control; fresh frames.', flush=True)
    print('全屏选择最近的可靠头部关键点；按住跟踪，松开再按重新选择。', flush=True)
    tracker = VisualTracker()
    controller = FractionalController(args.gain, args.pixels_per_count, args.max_step)
    print(f'CONTROL gain={args.gain} max_step={args.max_step}', flush=True)
    tracking_active = False
    last_control_time = None
    previous_error = None
    previous_track = None
    last_was_move = False
    print('正在预热模型，暂时不要切换窗口；预热完成后才开始绑定倒计时。', flush=True)
    warm_image = np.zeros((args.imgsz, args.imgsz, 3), dtype=np.uint8)
    for warm_index in range(2):
        warm_start = time.perf_counter()
        warm_result = model.predict(warm_image, imgsz=args.imgsz, device=args.device,
                                    conf=args.conf, verbose=False)[0]
        warm_result.boxes.xyxy.cpu().tolist()
        if args.device != 'cpu' and torch.cuda.is_available():
            torch.cuda.synchronize()
        print(f'WARMUP {warm_index+1}: {(time.perf_counter()-warm_start)*1000:.0f} ms', flush=True)
    if args.device != 'cpu' and torch.cuda.is_available():
        gpu_index = int(str(args.device).replace('cuda:', '').split(',')[0])
        free, total = torch.cuda.mem_get_info(gpu_index)
        print(f'GPU={torch.cuda.get_device_name(gpu_index)} free={free/2**30:.2f}GB total={total/2**30:.2f}GB', flush=True)
    del warm_result, warm_image
    hwnd, armed = None, False
    if video is None:
        print('请在 8 秒内切换到游戏窗口。', flush=True)
        time.sleep(8)
        hwnd = user32.GetForegroundWindow()
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not hwnd or pid.value == os.getpid():
            raise SystemExit('没有绑定到外部窗口，请重新启动。')
        bound_title, bound_class = window_info(hwnd)
        print(f'已绑定窗口：{hwnd} title={bound_title!r} class={bound_class!r}', flush=True)
        if bound_class in ('ConsoleWindowClass', 'CASCADIA_HOSTING_WINDOW_CLASS'):
            raise SystemExit('绑定到了终端，请重新启动并在提示后切到游戏。')
    print('不需要 F6/F8。绑定窗口保持前台 8 秒后自动开启；仍需按住右键。', flush=True)
    print('切出窗口立即关闭；切回后重新等待 8 秒。End 退出，终端 Ctrl+C 退出。', flush=True)
    overlay = None
    if video is None and not args.no_overlay:
        try:
            from overlay import Overlay
            overlay = Overlay()
        except Exception as exc:
            print('覆盖层创建失败：', str(exc), '；继续无覆盖层运行。', flush=True)
    focus_since = None
    last_report = 0.0
    move_calls = 0
    last_status = None
    def report(status, detail=''):
        nonlocal last_report, last_status
        now = time.perf_counter()
        if status != last_status or now - last_report >= 1:
            print(status, detail, flush=True)
            last_report, last_status = now, status

    print('默认透明覆盖层；日志同时保留带时间戳的副本，不必切出游戏查看预览。', flush=True)
    log_name = time.strftime('tracking_%Y%m%d_%H%M%S.csv')
    diagnostic_file = open(log_name, 'w', newline='', encoding='utf-8-sig')
    writer = csv.writer(diagnostic_file)
    writer.writerow(['time_s', 'reason', 'armed', 'foreground', 'right', 'detected',
                     'in_range', 'selection', 'track_id', 'error_px', 'error_change_px',
                     'frame_ms', 'dx', 'dy', 'calls', 'people', 'reliable_heads', 'gain', 'device', 'capture_ms', 'inference_ms', 'capture_backend'])
    log_start = time.perf_counter()
    last_flush = log_start
    title = 'Detection Preview V8' 
    preview_created = False
    capture = None
    try:
        with (mss.MSS if hasattr(mss, 'MSS') else mss.mss)() as screen:
            from capture import Capture
            capture = Capture(screen, args.capture) if video is None else None
            while not held(0x23):
                if overlay:
                    overlay.pump()
                started = time.perf_counter()
                if video is not None:
                    ok, frame = video.read()
                    if not ok:
                        break
                else:
                    if not hwnd or not user32.IsWindow(hwnd) or user32.IsIconic(hwnd):
                        if overlay:
                            overlay.hide()
                        armed = False
                        focus_since = None
                        tracker.reset()
                        tracking_active = False
                        controller.reset()
                        previous_error, previous_track, last_was_move = None, None, False
                        last_control_time = None
                        if last_status != 'PAUSED':
                            writer.writerow([round(time.perf_counter()-log_start, 3), 'PAUSED', 0, 0])
                            diagnostic_file.flush()
                        report('PAUSED', f'当前前台={window_info(user32.GetForegroundWindow())!r}；吸附已关闭。')
                        cv2.waitKey(1)
                        time.sleep(0.02)
                        continue
                    if user32.GetForegroundWindow() != hwnd:
                        if overlay:
                            overlay.hide()
                        armed = False
                        focus_since = None
                        tracker.reset()
                        tracking_active = False
                        controller.reset()
                        previous_error, previous_track, last_was_move = None, None, False
                        last_control_time = None
                        if last_status != 'PAUSED':
                            writer.writerow([round(time.perf_counter()-log_start, 3), 'PAUSED', 0, 0])
                            diagnostic_file.flush()
                        report('PAUSED', f'当前前台={window_info(user32.GetForegroundWindow())!r}；吸附已关闭。')
                        cv2.waitKey(1)
                        time.sleep(0.02)
                        continue
                    rect, origin = wintypes.RECT(), wintypes.POINT(0, 0)
                    if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
                        continue
                    if not user32.ClientToScreen(hwnd, ctypes.byref(origin)):
                        continue
                    width, height = rect.right, rect.bottom
                    if width < 32 or height < 32:
                        continue
                    frame = capture.grab(origin.x, origin.y, width, height)
                    if frame is None:
                        # Do not repeatedly infer/act on the previous desktop frame.
                        if user32.GetForegroundWindow() != hwnd:
                            focus_since, armed, tracking_active = None, False, False
                            tracker.reset()
                            if overlay:
                                overlay.hide()
                        time.sleep(0.002)
                        continue
                capture_ms = (time.perf_counter() - started) * 1000
                inference_started = time.perf_counter()
                height, width = frame.shape[:2]
                result = model.predict(frame, classes=person_ids, conf=args.conf, imgsz=args.imgsz,
                                       device=args.device, verbose=False)[0]
                people = result.boxes.xyxy.cpu().tolist()
                keypoints = result.keypoints.data.cpu().tolist() if result.keypoints is not None else []
                boxes = []
                if model.task == 'pose':
                    for box, points in zip(people, keypoints):
                        head = head_point(box, points, args.head_conf)
                        if head is not None:
                            boxes.append(list(box) + list(head))
                else:
                    boxes = [list(b)+[(b[0]+b[2])/2,(b[1]+b[3])/2] for b in people]
                radius = math.hypot(width, height) / 2  # Covers every point in the client image.
                inference_ms = (time.perf_counter() - inference_started) * 1000
                elapsed = time.perf_counter() - started
                foreground = video is None and user32.GetForegroundWindow() == hwnd
                right = held(0x02)
                now = time.perf_counter()
                if foreground:
                    if focus_since is None:
                        focus_since = now
                    armed = now - focus_since >= 8
                else:
                    focus_since, armed = None, False
                # Acquire CURRENT nearest target at activation / trigger press.
                if video is None:
                    tracking_now = armed and foreground and right and elapsed < 0.2
                    if not tracking_now or not tracking_active:
                        tracker.reset()
                        controller.reset()
                        previous_error, previous_track, last_was_move = None, None, False
                        last_control_time = None
                    tracking_active = tracking_now
                selection = tracker.update_frame(boxes, frame, radius, now)
                now = time.perf_counter()
                elapsed = now - started
                if not boxes and people and selection.target is None:
                    selection.status = 'NO_RELIABLE_HEAD'
                target = selection.target
                error = math.dist(target, (width/2, height/2)) if target else None
                error_change = None
                if (error is not None and previous_error is not None and last_was_move
                        and selection.track_id == previous_track):
                    error_change = error - previous_error
                control_dt = min(0.1, now-last_control_time) if last_control_time is not None else min(0.05, elapsed)
                last_control_time = now
                dx, dy = controller.update(target, width, height, control_dt, selection.track_id,
                                           cautious=selection.status == "FLOW_TRACKED")
                if video is not None:
                    reason = 'VIDEO_ONLY'
                elif not foreground:
                    reason = 'NO_FOCUS'
                elif not armed:
                    reason = 'COUNTDOWN'
                elif not right:
                    reason = 'WAIT_RIGHT'
                elif target is None:
                    reason = selection.status
                elif elapsed >= 0.2:
                    reason = 'STALE_FRAME'
                elif held(0x23):
                    break
                elif dx == 0 and dy == 0:
                    reason = 'IN_DEADZONE' if controller.in_deadzone else 'ACCUMULATING'
                elif not held(0x02) or user32.GetForegroundWindow() != hwnd:
                    reason = 'INPUT_CHANGED'
                else:
                    # A call proves only that an event was issued, not that the game accepted it.
                    reason = 'MOVE_CALL'
                    user32.mouse_event(0x0001, dx & 0xffffffff, dy & 0xffffffff, 0, 0)
                    move_calls += 1
                error_text = '-' if error is None else f'{error:.1f}'
                change_text = '-' if error_change is None else f'{error_change:+.1f}'
                detail = (f'armed={int(armed)} foreground={int(foreground)} right={int(right)} '
                          f'people={len(people)} heads={len(boxes)} in_range={selection.in_range} '
                          f'track={selection.track_id} selection={selection.status} '
                          f'error_px={error_text} change_px={change_text} '
                          f'capture={capture.backend if capture else "video"} ms={elapsed*1000:.0f} capture_ms={capture_ms:.0f} infer_ms={inference_ms:.0f} delta=({dx},{dy}) calls={move_calls}')
                report(reason, detail)
                writer.writerow([round(now-log_start, 3), reason, int(armed), int(foreground),
                                 int(right), selection.detected, selection.in_range,
                                 selection.status, selection.track_id, error_text, change_text,
                                 round(elapsed*1000, 1), dx, dy, move_calls, len(people), len(boxes), args.gain, args.device, round(capture_ms,1), round(inference_ms,1), capture.backend if capture else "video"])
                if now-last_flush >= 1:
                    diagnostic_file.flush()
                    last_flush = now
                previous_error, previous_track = error, selection.track_id
                last_was_move = reason == 'MOVE_CALL'
                if overlay:
                    if user32.GetForegroundWindow() == hwnd:
                        overlay.show(origin.x, origin.y, width, height, target,
                                     f'HEAD V8 {reason} | people={len(people)} heads={len(boxes)} '
                                     f'| {elapsed*1000:.0f}ms | BLUE CIRCLE: GUIDE ONLY')
                    else:
                        overlay.hide()
                if args.preview or video is not None:
                    preview = result.plot()
                    cv2.drawMarker(preview, (width // 2, height // 2), (255, 180, 0), markerSize=16, thickness=2)
                    if target:
                        cv2.circle(preview, tuple(map(round, target)), 6, (0, 0, 255), -1)
                        cv2.line(preview, (width//2, height//2), tuple(map(round, target)), (0,255,255), 2)
                    state = 'ON' if armed else 'OFF'
                    cv2.putText(preview, f'{state} {reason} RMB={int(right)} {elapsed*1000:.0f}ms',
                                (12, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    cv2.putText(preview, f'FULL SCREEN people={selection.detected} error={error_text}',
                                (12, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,255), 2)
                    if not preview_created:
                        cv2.namedWindow(title, cv2.WINDOW_NORMAL)
                        cv2.resizeWindow(title, 800, 450)
                        preview_created = True
                    cv2.imshow(title, preview)
                    if cv2.waitKey(1) == 27 or cv2.getWindowProperty(title, cv2.WND_PROP_VISIBLE) < 1:
                        break

    finally:
        if capture:
            capture.close()
        if overlay:
            overlay.close()
        diagnostic_file.close()
        import shutil
        shutil.copyfile(log_name, 'tracking_diagnostics.csv')
        if video is not None:
            video.release()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
