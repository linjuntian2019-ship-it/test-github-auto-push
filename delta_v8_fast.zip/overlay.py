"""Ordinary click-through Windows overlay. Requires a composited desktop."""
import ctypes as c
from ctypes import wintypes as w
import os


class Overlay:
    def __init__(self, exclude_from_capture=True):
        self.u = c.WinDLL('user32', use_last_error=True)
        self.g = c.WinDLL('gdi32', use_last_error=True)
        self.k = c.WinDLL('kernel32', use_last_error=True)
        self.width, self.height, self.target, self.label = 1, 1, None, ''
        self.hwnd = None
        self.callback_type = c.WINFUNCTYPE(c.c_ssize_t, w.HWND, w.UINT, c.c_size_t, c.c_ssize_t)

        class WNDCLASS(c.Structure):
            _fields_ = [('style', w.UINT), ('proc', self.callback_type),
                        ('clsExtra', c.c_int), ('wndExtra', c.c_int), ('instance', w.HINSTANCE),
                        ('icon', w.HANDLE), ('cursor', w.HANDLE), ('background', w.HBRUSH),
                        ('menu', w.LPCWSTR), ('name', w.LPCWSTR)]

        class PAINTSTRUCT(c.Structure):
            _fields_ = [('dc', w.HDC), ('erase', w.BOOL), ('rect', w.RECT),
                        ('restore', w.BOOL), ('update', w.BOOL), ('reserved', c.c_byte * 32)]
        self.Paint = PAINTSTRUCT
        # Pointer-sized signatures are essential on 64-bit Windows.
        def sig(lib, name, args, result):
            f = getattr(lib, name); f.argtypes = args; f.restype = result
        sig(self.k, 'GetModuleHandleW', [w.LPCWSTR], w.HMODULE)
        sig(self.u, 'RegisterClassW', [c.POINTER(WNDCLASS)], w.ATOM)
        sig(self.u, 'UnregisterClassW', [w.LPCWSTR, w.HINSTANCE], w.BOOL)
        sig(self.u, 'CreateWindowExW', [w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD,
            c.c_int, c.c_int, c.c_int, c.c_int, w.HWND, w.HMENU, w.HINSTANCE, c.c_void_p], w.HWND)
        sig(self.u, 'DefWindowProcW', [w.HWND, w.UINT, c.c_size_t, c.c_ssize_t], c.c_ssize_t)
        sig(self.u, 'BeginPaint', [w.HWND, c.POINTER(PAINTSTRUCT)], w.HDC)
        sig(self.u, 'EndPaint', [w.HWND, c.POINTER(PAINTSTRUCT)], w.BOOL)
        sig(self.u, 'FillRect', [w.HDC, c.POINTER(w.RECT), w.HBRUSH], c.c_int)
        sig(self.u, 'SetLayeredWindowAttributes', [w.HWND, w.DWORD, w.BYTE, w.DWORD], w.BOOL)
        sig(self.u, 'SetWindowDisplayAffinity', [w.HWND, w.DWORD], w.BOOL)
        sig(self.u, 'SetWindowPos', [w.HWND, w.HWND, c.c_int, c.c_int, c.c_int, c.c_int, w.UINT], w.BOOL)
        sig(self.u, 'ShowWindow', [w.HWND, c.c_int], w.BOOL)
        sig(self.u, 'InvalidateRect', [w.HWND, c.POINTER(w.RECT), w.BOOL], w.BOOL)
        sig(self.u, 'UpdateWindow', [w.HWND], w.BOOL)
        sig(self.u, 'DestroyWindow', [w.HWND], w.BOOL)
        sig(self.u, 'PeekMessageW', [c.POINTER(w.MSG), w.HWND, w.UINT, w.UINT, w.UINT], w.BOOL)
        sig(self.u, 'TranslateMessage', [c.POINTER(w.MSG)], w.BOOL)
        sig(self.u, 'DispatchMessageW', [c.POINTER(w.MSG)], c.c_ssize_t)
        sig(self.g, 'GetStockObject', [c.c_int], w.HANDLE)
        sig(self.g, 'CreatePen', [c.c_int, c.c_int, w.DWORD], w.HANDLE)
        sig(self.g, 'SelectObject', [w.HDC, w.HANDLE], w.HANDLE)
        sig(self.g, 'DeleteObject', [w.HANDLE], w.BOOL)
        sig(self.g, 'Ellipse', [w.HDC, c.c_int, c.c_int, c.c_int, c.c_int], w.BOOL)
        sig(self.g, 'MoveToEx', [w.HDC, c.c_int, c.c_int, c.POINTER(w.POINT)], w.BOOL)
        sig(self.g, 'LineTo', [w.HDC, c.c_int, c.c_int], w.BOOL)
        sig(self.g, 'SetBkMode', [w.HDC, c.c_int], c.c_int)
        sig(self.g, 'SetTextColor', [w.HDC, w.DWORD], w.DWORD)
        sig(self.g, 'TextOutW', [w.HDC, c.c_int, c.c_int, w.LPCWSTR, c.c_int], w.BOOL)
        self.instance = self.k.GetModuleHandleW(None)
        self.name = f'DeltaOverlayV6_{os.getpid()}'
        self.callback = self.callback_type(self._wndproc)
        wc = WNDCLASS()
        wc.proc, wc.instance, wc.name = self.callback, self.instance, self.name
        if not self.u.RegisterClassW(c.byref(wc)):
            raise c.WinError(c.get_last_error())
        # LAYERED | TRANSPARENT | NOACTIVATE | TOOLWINDOW. Mouse goes to underlying game.
        self.hwnd = self.u.CreateWindowExW(0x080800A0, self.name, 'Head Overlay V6',
            0x80000000, 0, 0, 1, 1, None, None, self.instance, None)
        if not self.hwnd:
            self.u.UnregisterClassW(self.name, self.instance)
            raise c.WinError(c.get_last_error())
        if not self.u.SetLayeredWindowAttributes(self.hwnd, 0, 255, 1):
            error = c.get_last_error(); self.close(); raise c.WinError(error)
        # Keep the overlay out of this program's own screen capture where supported.
        if exclude_from_capture and not self.u.SetWindowDisplayAffinity(self.hwnd, 0x11):
            print('Overlay capture exclusion unavailable; drawings may appear in captured frames.', flush=True)

    def _wndproc(self, hwnd, msg, wp, lp):
        if msg == 0x84:  # WM_NCHITTEST
            return -1  # HTTRANSPARENT
        if msg == 0x21:  # WM_MOUSEACTIVATE
            return 3  # MA_NOACTIVATE
        if msg == 0x14:
            return 1
        if msg == 0x0F:
            ps = self.Paint()
            dc = self.u.BeginPaint(hwnd, c.byref(ps))
            try:
                self._draw(dc)
            finally:
                self.u.EndPaint(hwnd, c.byref(ps))
            return 0
        return self.u.DefWindowProcW(hwnd, msg, wp, lp)

    def _draw(self, dc):
        rect = w.RECT(0, 0, self.width, self.height)
        self.u.FillRect(dc, c.byref(rect), self.g.GetStockObject(4))
        brush = self.g.SelectObject(dc, self.g.GetStockObject(5))
        pen = self.g.CreatePen(0, 2, 0xFFB400)
        old_pen = self.g.SelectObject(dc, pen)
        try:
            x, y = self.width // 2, self.height // 2
            r = int(min(self.width, self.height) * .18)
            self.g.Ellipse(dc, x-r, y-r, x+r, y+r)
            if self.target:
                tx, ty = map(round, self.target)
                self.g.Ellipse(dc, tx-12, ty-12, tx+12, ty+12)
                self.g.MoveToEx(dc, x, y, None)
                self.g.LineTo(dc, tx, ty)
            self.g.SetBkMode(dc, 1)
            self.g.SetTextColor(dc, 0xFFB400)
            self.g.TextOutW(dc, 16, 16, self.label, len(self.label))
        finally:
            self.g.SelectObject(dc, old_pen)
            self.g.SelectObject(dc, brush)
            self.g.DeleteObject(pen)

    def pump(self):
        msg = w.MSG()
        while self.u.PeekMessageW(c.byref(msg), None, 0, 0, 1):
            self.u.TranslateMessage(c.byref(msg))
            self.u.DispatchMessageW(c.byref(msg))

    def show(self, left, top, width, height, target, label):
        self.width, self.height, self.target, self.label = width, height, target, label
        if not self.u.SetWindowPos(self.hwnd, w.HWND(-1), left, top, width, height, 0x50):
            raise c.WinError(c.get_last_error())
        self.u.InvalidateRect(self.hwnd, None, False)
        self.u.UpdateWindow(self.hwnd)
        self.pump()

    def hide(self):
        if self.hwnd:
            self.u.ShowWindow(self.hwnd, 0)
            self.pump()

    def close(self):
        if self.hwnd:
            self.u.DestroyWindow(self.hwnd)
            self.hwnd = None
        self.u.UnregisterClassW(self.name, self.instance)
