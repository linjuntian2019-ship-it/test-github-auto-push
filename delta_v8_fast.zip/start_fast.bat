@echo off
cd /d "%~dp0"
".venv-gpu\Scripts\python.exe" main.py --device 0 --gain 20 --max-step 1200
pause
