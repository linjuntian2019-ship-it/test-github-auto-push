V8 使用说明

安装：退出旧程序，把本压缩包内的文件复制到原项目目录，替换同名文件。
保留原来的 .venv-gpu 和模型 .pt 文件。建议先备份旧 main.py 和 targeting.py。
不需要重装 PyTorch。不需要下载第三方模型即可试用。

启动：在原目录 PowerShell 执行
.\.venv-gpu\Scripts\python.exe .\main.py --device 0
也可双击 start_v8.bat。保持此前正常工作的权限设置。
预热后提示切换游戏，8秒绑定，持续前台8秒开启；按住右键工作。
End退出。切出游戏停止。继续保持此前游戏60 FPS限制，避免GPU争用。

本次改动：
1. 新画面上的稀疏光流前后向校验、纹理误差和运动一致性检查。
   检测中断最多补120ms；没有可靠当前画面证据时停止，不无限追踪旧点。
2. 先用光流补偿画面运动，再小幅过滤检测点的跳变。
3. 时间归一化指数修正，小数余量累计，反向清空余量。
4. 2像素停止范围；ACCUMULATING表示正在累计小数，不等同已经对准。
5. 每次运行保留 tracking_日期_时间.csv；退出后另复制到 tracking_diagnostics.csv。

可选开镜校准（建议准确度评估前做一次）：
先退出 main.py。进入训练场，保持同一瞄具/倍率/灵敏度，面对有纹理的静止墙面。
运行：
.\.venv-gpu\Scripts\python.exe .\calibrate.py
在8秒内切回游戏并按住右键。不要走动、射击或移动鼠标。
它会执行少量左右上下鼠标移动，约两秒后结束；End或松开右键取消。
成功会生成 calibration.json，下次 main.py 自动读取。
被拒绝时不会覆盖已有校准。此测量假设画面主要是静态背景，需本机验证。
改倍率/灵敏度/FOV/分辨率后重做。删除 calibration.json 恢复参考比例。
未校准时默认1:1只是参考值，不是你电脑的测量结果。

模型调研：
https://github.com/Abcfsa/YOLOv8_head_detector
作者提供nano.pt和medium.pt，使用SCUT-HEAD现实图像训练；不是三角洲专用模型。
https://github.com/HCIILAB/SCUT-HEAD-Dataset-Release
数据来源为教室监控和互联网现实图像，不能据此承诺游戏精度。
https://docs.ultralytics.com/modes/track/
BoT-SORT等维护身份并可补偿摄像机运动，但不提供脑门标注。
https://docs.opencv.org/3.4.15/d4/dee/tutorial_optical_flow.html
光流原理参考。当前实现不是引入第三方游戏插件，也不需要其可执行程序。

默认仍用你原来的yolov8n-pose.pt。没有捆绑未验证的第三方权重。
新增纯头部检测模型接口：
.\.venv-gpu\Scripts\python.exe .\main.py --device 0 --model 路径\head.pt --head-class 0
只有确认该类别确实为头部时才能使用；头框中心不等同脑门关键点。
适配接口已完成，但上述第三方权重没有在你的游戏画面上验证。

验证范围：4项合成算法测试通过；Windows窗口、覆盖层、游戏输入、校准器尚未本机实测。
不能保证完全遮挡时持续识别、区分敌我或准确停在脑门。
测试命令：python test_stabilization.py
