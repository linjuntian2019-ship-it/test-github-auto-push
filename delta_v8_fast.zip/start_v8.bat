@echo off
cd /d "%~dp0"
if not exist ".venv-gpu\Scripts\python.exe" (
  echo Copy this update into your existing V6 folder, keeping .venv-gpu.
  pause
  exit /b 1
)
".venv-gpu\Scripts\python.exe" main.py --device 0 %*
pause
