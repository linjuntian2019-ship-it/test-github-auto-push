"""Geometry-based association; this is not enemy identification or a trained tracker."""
import math
from dataclasses import dataclass


def aim_point(box):
    if len(box) == 6:
        return box[4], box[5]
    x1, y1, x2, y2 = box
    return (x1 + x2) / 2, y1 + (y2 - y1) * 0.4


def overlap(a, b):
    width = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    height = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = width * height
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter
    return inter / union if union > 0 else 0


@dataclass
class Selection:
    target: object
    box: object
    detected: int
    in_range: int
    status: str
    track_id: object


class TargetTracker:
    def __init__(self, grace=0.35):
        self.grace = grace
        self.serial = 0
        self.reset()

    def reset(self):
        self.box = None
        self.last_seen = None
        self.track_id = None
        self.shape = None
        self.pending_head = None

    def update(self, boxes, width, height, radius, now):
        if self.shape != (width, height):
            self.reset()
            self.shape = (width, height)
        valid = [tuple(map(float, b)) for b in boxes
                 if len(b) == 6 and all(math.isfinite(v) for v in b)
                 and b[2] > b[0] and b[3] > b[1]]
        center = width / 2, height / 2
        candidates = [b for b in valid if math.dist(aim_point(b), center) <= radius]
        if self.box is not None and now - self.last_seen > self.grace:
            self.box = None
            self.track_id = None
            self.pending_head = None
        if self.box is not None:
            matches = [(overlap(self.box, b), b) for b in candidates]
            score, best = max(matches, default=(0, None), key=lambda pair: pair[0])
            if score >= 0.15:
                def relative_head(b):
                    return ((b[4]-b[0])/(b[2]-b[0]), (b[5]-b[1])/(b[3]-b[1]))
                old_head, new_head = relative_head(self.box), relative_head(best)
                if math.dist(old_head, new_head) > 0.15:
                    if self.pending_head is None or math.dist(self.pending_head, new_head) > 0.05:
                        self.pending_head = new_head
                        return Selection(None, None, len(valid), len(candidates), 'HEAD_JUMP', self.track_id)
                self.pending_head = None
                self.box, self.last_seen = best, now
                return Selection(aim_point(best), best, len(valid), len(candidates),
                                 'TRACKED', self.track_id)
            # Remember identity briefly; NEVER return an old position for movement.
            status = ('NO_DETECTION' if not valid else
                      'OUT_OF_RANGE' if not candidates else 'TRACK_LOST')
            return Selection(None, None, len(valid), len(candidates), status, self.track_id)
        if not candidates:
            return Selection(None, None, len(valid), 0,
                             'NO_DETECTION' if not valid else 'OUT_OF_RANGE', None)
        self.box = min(candidates, key=lambda b: math.dist(aim_point(b), center))
        self.last_seen = now
        self.serial += 1
        self.track_id = self.serial
        return Selection(aim_point(self.box), self.box, len(valid), len(candidates),
                         'ACQUIRED', self.track_id)


def select_target(boxes, width, height, radius):
    return TargetTracker().update(boxes, width, height, radius, 0).target


def movement(target, width, height, gain=1.2, max_step=120, dt=0.05, deadzone=4):
    dx, dy = target[0] - width / 2, target[1] - height / 2
    distance = math.hypot(dx, dy)
    if not math.isfinite(distance) or distance <= deadzone:
        return 0, 0
    # Continuous gain transition: no sudden increase at the old 24px boundary.
    blend = min(1.0, max(0.0, (distance - 24) / 96))
    smooth = blend * blend * (3 - 2 * blend)
    near_gain = min(0.4, gain)
    effective_gain = near_gain + (gain - near_gain) * smooth
    # Preserve approximate input per second when capture FPS changes.
    frame_scale = min(2.0, max(0.1, dt / 0.05))
    step = min(max_step, effective_gain * distance) * frame_scale
    return round(dx * step / distance), round(dy * step / distance)


def head_point(box, keypoints, threshold=0.5):
    """COCO first five landmarks: nose, eyes, ears. Require >=2 reliable points."""
    if len(keypoints) < 5:
        return None
    x1, y1, x2, y2 = box
    valid = {}
    for i, point in enumerate(keypoints[:5]):
        if len(point) >= 3:
            x, y, conf = point[:3]
            if (all(math.isfinite(v) for v in (x, y, conf)) and conf >= threshold
                    and x1 <= x <= x2 and y1 <= y <= y2):
                valid[i] = (x, y, conf)
    if len(valid) < 2:
        return None
    if 1 in valid and 2 in valid:
        return ((valid[1][0]+valid[2][0])/2, (valid[1][1]+valid[2][1])/2)
    if 0 in valid:
        return valid[0][0], valid[0][1]
    total = sum(p[2] for p in valid.values())
    return tuple(sum(p[axis]*p[2] for p in valid.values())/total for axis in (0,1))
