"""Optional local ADS calibration using observed image translation, not log guesses."""
import ctypes
from ctypes import wintypes
import time
import json
import math
from pathlib import Path
import cv2
import mss
import numpy as np


def main():
    u=ctypes.WinDLL('user32')
    u.SetProcessDPIAware()
    u.GetForegroundWindow.restype=wintypes.HWND
    u.GetClientRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
    u.ClientToScreen.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.POINT)]
    u.GetAsyncKeyState.restype=ctypes.c_short
    u.mouse_event.argtypes=[wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,ctypes.c_size_t]
    held=lambda key: bool(u.GetAsyncKeyState(key)&0x8000)
    print('8 seconds: focus game, hold RIGHT, face a static textured wall; do not fire or move. END cancels.')
    time.sleep(8)
    hwnd=u.GetForegroundWindow()
    u.GetClassNameW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    name=ctypes.create_unicode_buffer(256)
    u.GetClassNameW(hwnd,name,256)
    if name.value in ('ConsoleWindowClass','CASCADIA_HOSTING_WINDOW_CLASS'):
        raise SystemExit('Cancelled: a terminal was selected.')
    def valid():return held(2) and not held(0x23) and u.GetForegroundWindow()==hwnd
    if not valid():raise SystemExit('Cancelled: RIGHT must be held in the game.')
    rect=wintypes.RECT();origin=wintypes.POINT(0,0)
    if not u.GetClientRect(hwnd,ctypes.byref(rect)) or not u.ClientToScreen(hwnd,ctypes.byref(origin)):
        raise SystemExit('Cannot read window bounds.')
    if rect.right<200 or rect.bottom<200:raise SystemExit('Window too small.')
    values=[[],[]]
    with (mss.MSS if hasattr(mss,'MSS') else mss.mss)() as screen:
        def snap():
            im=np.asarray(screen.grab(dict(left=origin.x,top=origin.y,width=rect.right,height=rect.bottom)))[:,:,:3]
            # Upper central scene avoids the weapon, reticle and most HUD elements.
            h,w=im.shape[:2]
            roi=im[int(h*.15):int(h*.42),int(w*.25):int(w*.75)]
            return cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY).astype(np.float32)
        for axis in (0,1):
            for direction in (1,-1,1,-1):
                if not valid():raise SystemExit('Cancelled: focus/button changed; no calibration saved.')
                a=snap();count=16*direction
                if not valid():raise SystemExit('Cancelled.')
                u.mouse_event(1,count&0xffffffff if axis==0 else 0,
                              count&0xffffffff if axis==1 else 0,0,0)
                time.sleep(.18)
                b=snap()
                if not valid():raise SystemExit('Cancelled: no calibration saved.')
                window=cv2.createHanningWindow((a.shape[1],a.shape[0]),cv2.CV_32F)
                shift,response=cv2.phaseCorrelate(a,b,window)
                scale=-shift[axis]/count
                if response>.5 and .05<scale<30 and abs(shift[1-axis])<max(3,abs(shift[axis])*.2):
                    values[axis].append(scale)
        if any(len(v)<3 for v in values):
            raise SystemExit('Calibration rejected: inconsistent scene motion. Existing calibration unchanged.')
        scales=[float(np.median(v)) for v in values]
        if any(max(abs(x-scales[i]) for x in v)/scales[i]>.20 for i,v in enumerate(values)):
            raise SystemExit('Calibration rejected: measurements disagree. Existing calibration unchanged.')
    dest=Path(__file__).with_name('calibration.json')
    dest.write_text(json.dumps({'pixels_per_count':scales,'note':'ADS only; recalibrate after sensitivity/FOV/scope/resolution changes'},indent=2))
    print('Saved:',dest,'pixels per mouse count:',scales)

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:pass
